=== Prime Timeline ===
Contributors: primestrategy, Kengyu Nakamura, jim912, tajima_taso, Koichiro Nakadori
Tags: debug, tools, develop, study
Requires at least: 3.3
Tested up to: 4.1.1
Stable tag: 1.0.4
License: GPLv2 or later

This plugin analyze the execution status of WordPress for debugging, performance check, and study.

== Description ==

This plugin analyze the execution status of WordPress for debugging, performance check, and study.

Display all the hooks, all the queries, all the loaded files, and some information for the current request.

= Special Thanks =
 * Kengyu Nakamura
 * Yuya Tajima
 * Yachiyo Nishimaki
 * Hitoshi Omagari
 * Yongjia Xie
 * Koichiro Nakadori
 * Yuta Sakamoto
 * Yoshihiro Oshima

== Installation ==

1. Upload the prime-timeline directory to the plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. You will find 'Prime Timeline' within the admin bar while logged in.

== Changelog ==
= 1.0.4 =
* Initial Public Release
