<div id="ps_wrap" style="display:none;">
	<div id="ps_head">
		<ul>
			<li><ul id="ps_all">
				<li class="ps_filter"><a href="#">All Timeline</a></li>
			</ul><li>
			<li><ul id="ps_file">
				<li class="ps_filter"><a href="#">Loaded Files</a></li>
				<li class="ps_show"><a href="#">+show</a></li>
				<li class="ps_hide"><a href="#">-hide</a></li>
			</ul><li>
			<li><ul id="ps_sql">
				<li class="ps_filter"><a href="#">SQL Queries</a></li>
				<li class="ps_show"><a href="#">+show</a></li>
				<li class="ps_hide"><a href="#">-hide</a></li>
			</ul><li>
			<li><ul id="ps_hook">
				<li class="ps_filter"><a href="#">All Hooks</a></li>
				<li class="ps_show"><a href="#">+show</a></li>
				<li class="ps_hide"><a href="#">-hide</a></li>
			</ul><li>
			<li><ul id="ps_hook_do">
				<li class="ps_filter"><a href="#">Registerd Hooks</a></li>
				<li class="ps_show"><a href="#">+show</a></li>
				<li class="ps_hide"><a href="#">-hide</a></li>
			</ul><li>
			<li><ul id="ps_hook_pass">
				<li class="ps_filter"><a href="#">Passed Hooks</a></li>
				<li class="ps_show"><a href="#">+show</a></li>
				<li class="ps_hide"><a href="#">-hide</a></li>
			</ul><li>
			<li><ul id="ps_slow">
				<li class="ps_filter"><a href="#">Slow Points</a></li>
				<li class="ps_show"><a href="#">+show</a></li>
				<li class="ps_hide"><a href="#">-hide</a></li>
			</ul><li>
			<li><ul>
				<li><input type='text' id='ps_slow_search' value='10' /></li>
			</ul><li>
		</ul>
	</div>
	<div id="ps_panel">
__ps_footer__
	</div>
</div>
