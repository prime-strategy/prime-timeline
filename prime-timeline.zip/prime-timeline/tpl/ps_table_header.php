<p><?php echo sprintf( 'Total execution time (%.2f msec)', $exec); ?></p>
<table>
	<tbody>
		<tr id='ps_tr_head'>
			<th width='5%'>No.</th>
			<th width='5%'>Total<br />(msec)</th>
			<th width='10%'>Type</th>
			<th width='5%'>File</th>
			<th width='30%'>Hook/SQL</th>
			<th width='30%'>Detail</th>
			<th width='5%'>Count</th>
			<th width='5%'>Diff<br />(msec)</th>
			<th width='5%'>This<br />(msec)</th>
		</tr>

